import pygame
import random
pygame.init()
width=1500
height=600
run=True
screen=pygame.display.set_mode((width,height))
answer_true=[pygame.image.load('answer_true.jpg').convert(),True]
answer_true[0]=pygame.transform.scale(answer_true[0],(400,200))
answer_false1=[pygame.image.load('answer_false1.jpg').convert(),False]
answer_false1[0]=pygame.transform.scale(answer_false1[0],(400,200))
answer_false2=[pygame.image.load('answer_false2.jpg').convert(),False]
answer_false2[0]=pygame.transform.scale(answer_false2[0],(400,200))
answer_false3=[pygame.image.load('answer_false3.jpg').convert(),False]
answer_false3[0]=pygame.transform.scale(answer_false3[0],(400,200))
answer_list=[answer_true,answer_false1,answer_false2,answer_false3]
answer=-1

congratulation=(pygame.image.load('congratulation1.jpg').convert())
duty=-1

wrong=(pygame.image.load('wrong1.jpg').convert())

choose=None

def answer_apear(oder_answer_list):
    screen.blit(oder_answer_list[0][0],(300,75))
    screen.blit(oder_answer_list[1][0],(900,75))
    screen.blit(oder_answer_list[2][0],(300,325))
    screen.blit(oder_answer_list[3][0],(900,325))
def sort_answer(answer_true,answer_false1,answer_false2,answer_false3):
    answer_list=[answer_true,answer_false1,answer_false2,answer_false3]
    oder_answer_list=[]
    for i in range(len(answer_list)):
        oder_number=random.choice(answer_list)
        oder_answer_list.append(oder_number)
        answer_list.remove(oder_number)
    return oder_answer_list




def choose_answer1(oder_answer_list,choose,answer):
    if oder_answer_list[0][0].get_rect(topleft=(300, 75)).collidepoint(event.pos):
        choose=oder_answer_list[0]
        if oder_answer_list[0][1]:
            answer=0
        else:
            answer=1
    if oder_answer_list[1][0].get_rect(topleft=(900, 75)).collidepoint(event.pos):
        choose=oder_answer_list[0]
        if oder_answer_list[1][1]:
            answer=0
        else:
            answer=1
    if oder_answer_list[2][0].get_rect(topleft=(300, 325)).collidepoint(event.pos):
        choose=oder_answer_list[0]
        if oder_answer_list[2][1]:
            answer=0
        else:
            answer=1
    if oder_answer_list[3][0].get_rect(topleft=(900, 325)).collidepoint(event.pos):
        choose=oder_answer_list[0]
        if oder_answer_list[3][1]:
            answer=0
        else:
            answer=1
    return answer


def choose_answer2(answer,congratulation,wrong):
    if answer==0:
        screen.blit(congratulation,(300,75))
    elif answer==1:
        screen.blit(wrong,(300,75))

#để ngoài while
oder_answer_list=sort_answer(answer_true,answer_false1,answer_false2,answer_false3)

while run:
    
    answer_apear(oder_answer_list)
    
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
#phần nghi bị lỗi
        if event.type==pygame.MOUSEBUTTONDOWN:
            answer=choose_answer1(oder_answer_list,choose,answer)
    choose_answer2(answer,congratulation,wrong)
    pygame.display.flip()
#mong cô hỗ trợ ạ
                
pygame.quit()



