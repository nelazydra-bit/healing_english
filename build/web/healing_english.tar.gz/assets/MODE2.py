import pygame
import random
pygame.init()
width=1500
height=600
screen=pygame.display.set_mode((width,height))
ques=0#đếm câu hỏi
#bộ câu hỏi
question1=(pygame.image.load('question1.jpg').convert_alpha())
question1=pygame.transform.scale(question1,(550,height))
question1.set_colorkey((0,0,0))
#câu hỏi 1
answer1_true=[pygame.image.load('answer_true.png').convert_alpha(),True]
answer1_true[0]=pygame.transform.scale(answer1_true[0],(400,200))
answer1_true[0].set_colorkey((0,0,0))
answer1_false1=[pygame.image.load('answer_false1.png').convert_alpha(),False]
answer1_false1[0]=pygame.transform.scale(answer1_false1[0],(400,200))
answer1_false1[0].set_colorkey((0,0,0))
answer1_false2=[pygame.image.load('answer_false2.png').convert_alpha(),False]
answer1_false2[0]=pygame.transform.scale(answer1_false2[0],(400,200))
answer1_false2[0].set_colorkey((0,0,0))
answer1_false3=[pygame.image.load('answer_false3.png').convert_alpha(),False]
answer1_false3[0]=pygame.transform.scale(answer1_false3[0],(400,200))
answer1_false3[0].set_colorkey((0,0,0))
answer1_list=[answer1_true,answer1_false1,answer1_false2,answer1_false3]
answer=-1
choose=None
#câu hỏi 2
answer2_true=[pygame.image.load('answer2_true.png').convert_alpha(),True]
answer2_true[0]=pygame.transform.scale(answer2_true[0],(400,200))
answer2_true[0].set_colorkey((0,0,0))
answer2_false1=[pygame.image.load('answer2_false1.png').convert_alpha(),False]
answer2_false1[0]=pygame.transform.scale(answer2_false1[0],(400,200))
answer2_false1[0].set_colorkey((0,0,0))
answer2_false2=[pygame.image.load('answer2_false2.png').convert_alpha(),False]
answer2_false2[0]=pygame.transform.scale(answer2_false2[0],(400,200))
answer2_false2[0].set_colorkey((0,0,0))
answer2_false3=[pygame.image.load('answer2_false3.png').convert_alpha(),False]
answer2_false3[0]=pygame.transform.scale(answer2_false3[0],(400,200))
answer2_false3[0].set_colorkey((0,0,0))
answer2_list=[answer2_true,answer2_false1,answer2_false2,answer2_false3]
answer2=-1
#câu hỏi 3 đang sửa
answer3_true=[pygame.image.load('answer2_false1.png').convert_alpha(),True]
answer3_true[0]=pygame.transform.scale(answer3_true[0],(400,200))
answer3_true[0].set_colorkey((0,0,0))
answer3_false1=[pygame.image.load('answer2_true.png').convert_alpha(),False]
answer3_false1[0]=pygame.transform.scale(answer3_false1[0],(400,200))
answer3_false1[0].set_colorkey((0,0,0))
answer3_false2=[pygame.image.load('answer2_false2.png').convert_alpha(),False]
answer3_false2[0]=pygame.transform.scale(answer3_false2[0],(400,200))
answer3_false2[0].set_colorkey((0,0,0))
answer3_false3=[pygame.image.load('answer2_false3.png').convert_alpha(),False]
answer3_false3[0]=pygame.transform.scale(answer3_false3[0],(400,200))
answer3_false3[0].set_colorkey((0,0,0))
answer3_list=[answer3_true,answer3_false1,answer3_false2,answer3_false3]
answer3=-1

#đáp án 1
congratulation=(pygame.image.load('congratulation1.jpg').convert())
wrong=(pygame.image.load('wrong1.png').convert())

def sort_answer(answer_list):
    another_list=answer_list
    oder_answer_list=[]
    for i in range(len(another_list)):
        oder_number=random.choice(answer_list)
        oder_answer_list.append(oder_number)
        another_list.remove(oder_number)
        
    return oder_answer_list

def answer_apear(oder_answer_list):
    screen.blit(oder_answer_list[0][0],(600,75))
    screen.blit(oder_answer_list[1][0],(1000,75))
    screen.blit(oder_answer_list[2][0],(600,325))
    screen.blit(oder_answer_list[3][0],(1000,325))


def choose_answer1(oder_answer_list,choose,answer):
    if oder_answer_list[0][0].get_rect(topleft=(600,75)).collidepoint(event.pos):
        choose=oder_answer_list[0]
        if oder_answer_list[0][1]:
            answer=0
        else:
            answer=1
    if oder_answer_list[1][0].get_rect(topleft=(1000,75)).collidepoint(event.pos):
        choose=oder_answer_list[0]
        if oder_answer_list[1][1]:
            answer=0
        else:
            answer=1
    if oder_answer_list[2][0].get_rect(topleft=(600,325)).collidepoint(event.pos):
        choose=oder_answer_list[0]
        if oder_answer_list[2][1]:
            answer=0
        else:
            answer=1
    if oder_answer_list[3][0].get_rect(topleft=(1000,325)).collidepoint(event.pos):
        choose=oder_answer_list[0]
        if oder_answer_list[3][1]:
            answer=0
        else:
            answer=1
    return answer


def choose_answer2(answer,congratulation,wrong,ques):
    if answer==1:
        screen.blit(wrong,(300,75))
    elif answer==0:
        ques+=1
    return ques


oder_answer_list1=sort_answer(answer1_list)
oder_answer_list2=sort_answer(answer2_list)
oder_answer_list3=sort_answer(answer3_list)
print(oder_answer_list2[0][1])
run=True
while run:
    screen.fill((250,250,250))
    if ques==0:
        answer_apear(oder_answer_list1)
        ques=choose_answer2(answer,congratulation,wrong,ques)
        answer=-1
        
    elif ques==1:
        question1=(pygame.image.load('question2.jpg').convert_alpha())
        question1=pygame.transform.scale(question1,(550,height))
        question1.set_colorkey((0,0,0))
        answer_apear(oder_answer_list2)
        ques=choose_answer2(answer2,congratulation,wrong,ques)
        
    elif ques==2:
        question1=(pygame.image.load('question3.jpg').convert_alpha())
        question1=pygame.transform.scale(question1,(550,height))
        question1.set_colorkey((0,0,0))
        answer_apear(oder_answer_list3)
        ques=choose_answer2(answer3,congratulation,wrong,ques)
    elif ques==3:
        run=False
    screen.blit(question1,(0,0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if ques == 0:
                answer = choose_answer1(oder_answer_list1, choose, answer )
            elif ques == 1:
                answer2 = choose_answer1(oder_answer_list2, choose, answer2)
            elif ques == 2:
                answer3 = choose_answer1(oder_answer_list3, choose, answer3)                
     
     
        
        
    pygame.display.flip()

pygame.quit()
