function dongBang () {
     document.getElementById('introBox').style.display = 'none';
}
function xoaBangThongTin() {
    document.getElementById("gameModal").style.display = "none";
}
function moBangThongTin() {
    document.getElementById("gameModal").style.display = "flex";
}